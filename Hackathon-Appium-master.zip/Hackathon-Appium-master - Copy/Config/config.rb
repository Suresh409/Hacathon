
#Serial/Parallel
$executionMode = Serial
$sendmail = false
$TOEmailID = 'Suresh.Reddy02@infosys.com'
$CCEmailIDs = 'Purusothaman.R@infosys.com'
$apkName = android.apk
$ipaName = ios.ipa

