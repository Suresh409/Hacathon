#syntax = $variableName = tagname, propertyName, propertyValue

$textbox = "text_field,name,q"
$btn = "button,class,vh79eN"
