#syntax = $variableName = tagname, propertyName, propertyValue,index

$textbox = "text_field,class,android.widget.Button"
$btn = "button,class,vh79eN,0"
$btn1 = "button,class,android.widget.Button,0"
